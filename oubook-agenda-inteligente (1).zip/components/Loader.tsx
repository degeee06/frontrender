
import React from 'react';

const Loader: React.FC = () => {
    return <div className="loading-spinner"></div>;
};

export default Loader;
